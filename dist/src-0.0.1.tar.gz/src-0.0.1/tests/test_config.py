

def test_check():
    a = 5
    b = 7
    c=a+b
    assert c>10